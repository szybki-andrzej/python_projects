#zad1

def binom(n,k):
    """Returns value of binomial coefficient based on given values."""
    if k == 0:
        return 1
    if n == k:
        return 1
    else:
        return binom(n-1,k-1) + binom(n-1,k)

def easypow(x,n):
    """Returns n-power of x but in easier way."""
    if n == 0:
        return 1
    if n%2 == 1:
        return x*easypow(x, n-1)
    else:
        a = easypow(x,n/2)
    return a*a

def maxsucc(p,n,k):
    """Returns probability of at most k succeses on given parameters."""
    q = p/(1-p)
    r=1
    sum0 = 0
    for i in range(0,k+1):
        r = r*q
        sum0 = sum0+(binom(n,i)*r)
    return sum0*easypow(1-p,n)

#zad2

def horner(a, x):
    """Returns the value of polynomial with given coefficients."""
    
    n = len(a)
    mul = 0
    w = 0
    for i in range(0,n-1):
        w = x*(a[n-i-1]+w)
        mul = mul+1
    return w + a[n-1], mul

#zad3

def charcounter(file):
    """Returns number of every letter occured in text packed in file."""
    f = open(file,"r")
    text = f.read()
    text = text.lower()

    results = {}
    letters = "abcdefghijklmnopqrstvuwxyz"
    for i in range(len(letters)):
        results[letters[i]] = text.count(letters[i])
    return results
    
    
def main():
    print(binom(8,4))
    print(easypow(2,12))
    print(maxsucc(0.3,10,1))
    print(horner([1,1,1,1],2))
    print(charcounter("tekst.txt"))

if __name__ =="__main__":
    main()
