import numpy as np
import matplotlib.pyplot as plt
import time
import random

#task1

class QueueBeg:
    """Object in type of queue in which items are added in the beginning and deleted from the end."""
    def __init__(self):
        """Initialization function."""
        
        self.items = []

    def isEmpty(self):
        """Checks if Queue is empty."""
        
        return self.items == []

    def enqueue(self, item):
        """Adds element n given parameters."""
        
        self.items.insert(0,item)

    def dequeue(self):
        """Delete element and return the value."""
        
        return self.items.pop()

    def size(self):
        """Returns the lengh if the queue."""
        
        return len(self.items)

class QueueEnd:
    """Object in type of queue in which items are added at the end and deleted from the beginning."""
    def __init__(self):
        """Initialization function."""
        
        self.items = []

    def isEmpty(self):
        """Checks if Queue is empty."""
        
        return self.items == []

    def enqueue(self, item):
        """Adds element n given parameters."""
        
        self.items.append(item)

    def dequeue(self):
        """Delete element and return the value."""
        
        return self.items.pop(0)

    def size(self):
        """Returns the lengh if the queue."""
        
        return len(self.items)


#task2
    
def queue_testing():
    """Function that compares speed of two previous classes' methods."""
    att = 100


    front = QueueBeg()

    start = time.time()
    for i in range(0,att):
        front.enqueue(i)
    for i in range(0,att):
        front.dequeue()
    print("Front FIFO:")
    print(time.time()-start)

    back = QueueEnd()

    start = time.time()
    for i in range(0,att):
        back.enqueue(i)
    for i in range(0,att):
        back.dequeue()
    print("Backward FIFO:")
    print(time.time()-start)

#task3
#ile średnio trzeba czekać w kolejce do kasy w sklepie?
class Assistant:
    """Object Assistant."""

    def __init__(self,cpt):
        """Initialization function."""
        
        self.pagerate = cpt
        self.currentTask = None
        self.timeRemaining = 0

    def busy(self):
        """Checks if assistant is busy."""
        
        if self.currentTask != None:
            return True
        else:
            return False

    def startNext(self,newtask):
        """Makes assistant start new task."""
        
        self.currentTask = newtask
        self.timeRemaining = 60

    def tick(self):
        """Counts time."""
        
        if self.currentTask != None:
            self.timeRemaining = self.timeRemaining - 1
            if self.timeRemaining <= 0:
                self.currentTask = None

class Client:
    """Object Client."""
    
    def __init__(self,time):
        """Initialization function."""
        
        self.timestamp = time

    def getStamp(self):
        """Helps in counting time."""
        
        return self.timestamp

    def waitTime(self, currenttime):
        """Returns waittime."""
        
        return currenttime - self.timestamp

def newClient():
    """Checks if there is new client."""
    
    num = random.randrange(1,21)
    if num == 21:
        return True
    else:
        return False

def simulation(numSeconds, clientsintime):
    """Makes simulation."""
    
    clientQueue = QueueBeg()
    waitingtimes =[]
    assistant = Assistant(clientsintime)

    for currentSecond in range(numSeconds):

        if newClient():
            client = Client(currentSecond)
            clientQueue.enqueue(task)

        if (not assistant.busy()) and (not clientQueue.isEmpty()):
            nexttask = clientQueue.enqueue()
            waitingtimes.append(nexttask.waitTime(currentSecond))
            assistant.startNext(nexttask)

        assistant.tick()

    averageWait=sum(waitingtimes)/len(waitingtimes)
    print("Average Wait %6.2f secs %3d clients remaining."%(averageWait,printQueue.size()))

    
            
            
    


#task4

class Stack:
    """Object in type of Stack."""
    
    def __init__(self):
        """Initalization function."""
        
        self.items = []

    def isEmpty(self):
        """Checks if Stack is empty."""
        
        return self.items == []

    def push(self, item):
        """Adds element to stack on given parameters."""
        
        self.items.append(item)

    def pop(self):
        """Delete element from stack and returns the value."""
        
        return self.items.pop()

    def peek(self):
        """Returns the value of last element."""
        
        return self.items[len(self.items)-1]

    def size(self):
        """Returns the number of elements in stack."""
        
        return len(self.items)


def rm_self_tags(html_file):
    """Removes unnecesary symbols."""
    
    exceptions = ['<!','<area','<base','<br','<col','<embed','<hr','<img','<input','<link','<meta','<param','<source','<track','<wbr']
    text = open(html_file).read()
    for i in exceptions:
        text = text.replace(i,"")
    return text

def parChecker(symbolString):
    """Returns if syntaxes in code were used properly."""
    s = Stack()         
    balanced = True     
    index = 0
    while index < len(symbolString) and balanced:
        symbol = symbolString[index]
        if symbol == "<":
            if symbolString[index+1] != "/":
                s.push(symbol)
            else:
                if s.isEmpty():                       
                    balanced = False
                else:
                    s.pop()                            
        index = index + 1

    if balanced and s.isEmpty():
        return True
    else:
        return False

#task5

class Node:
    """Class that describes element of unordered list."""
    
    def __init__(self,initdata):
        """Initalization function."""
        
        self.data = initdata
        self.next = None

    def getData(self):
        """Returns the value of node."""
        
        return self.data

    def getNext(self):
        """Returns the value of next node."""
        
        return self.next

    def setData(self,newdata):
        """Sets up the value of node."""
        
        self.data = newdata

    def setNext(self,newnext):
        """Sets up the value of next node."""
        
        self.next = newnext


class UnorderedList:
    """Class representing unordered list."""

    def __init__(self):
        """Initialization function."""
        
        self.head = None

    def isEmpty(self):
        """Checks if list is empty."""
        
        return self.head == None

    def add(self,item):
        """Adds element at the beginning."""
        
        temp = Node(item)
        temp.setNext(self.head)
        self.head = temp

    def size(self):
        """Returns the length of the list."""
        
        current = self.head
        count = 0
        while current != None:
            count = count + 1
            current = current.getNext()

        return count

    def search(self,item):
        """Checks if item is on the list."""
        
        current = self.head
        found = False
        while current != None and not found:
            if current.getData() == item:
                found = True
            else:
                current = current.getNext()

        return found

    def remove(self,item):
        """Removes item from the list."""
        
        current = self.head
        previous = None
        found = False
        if self.isEmpty():
            print("List already empty")
            return 
        while not found:
            if current.getData() == item:
                found = True
            else:
                previous = current
                current = current.getNext()
                if current == None:
                    print("Item not found")
                    return 

        if previous == None:                  
            self.head = current.getNext()
        else:
            previous.setNext(current.getNext())
            
    def index(self,item):
        """Returns the index of item."""
        
        current = self.head
        found = 0
        while current != None:
            if current.getData() == item:
                return found
            else:
                current = current.getNext()
            found = found+1

        print("Item is not on the list")

    def append(self,item):
        """Adds element at the end of the list."""
        
        temp = Node(item)
        current = self.head
        if current == None:
            self.add(item)
        else:
            while current.getNext() != None:
                current = current.getNext()
            current.setNext(temp)
    
    def pop(self,pos = None):
        """Deletes the element and returns value."""
        
        if pos == None:
            pos = self.size()-1
        current = self.head
        previous = None
        for i in range(pos):
            previous = current
            current = current.getNext()
        if previous !=None:
            previous.setNext(current.getNext())
        return current.getData()

    
    def __str__(self):
        """String represenation."""
        
        current = self.head
        li = []
        while current != None:
            li.append(current.getData())
            current = current.getNext()
        s = ("[" + ', '.join(['{}']*len(li))+"]") 
        return s.format(*li)

#task6

class StackUnordered:
    """Stack but written with unordered list."""
    
    def __init__(self):
        """Initialization function."""
        
        self.items = UnorderedList()

    def isEmpty(self):
        """Checks if stack is empty."""
        
        return self.items == []

    def push(self, item):
        """Adds element to stack."""
        
        self.items.append(item)

    def pop(self):
        """Removes element and returns value."""
        
        return self.items.pop()

    def peek(self):
        """Returns the value of last element."""
        
        return self.items[self.items.size()-1]

    def size(self):
        """Returns number of the elements in stack."""
        
        return self.items.size()


#task7

class TwoSideQueue():
    """Queue but with two side access."""
    
    def __init__(self):
        """Initialization function."""
        
        self.items = []

    def isEmpty(self):
        """Checks if queue is empty."""
        
        return self.items == []

    def enqueuefront(self, item):
        """Adds element in front."""
        
        self.items.insert(0,item)

    def enqueueback(self, item):
        """Adds element at the end."""
        
        self.items.insert(len(self.items)-1,item)

    def dequeuefront(self):
        """Remove element from the beginning."""
        
        return self.items.pop()

    def dequeueback(self):
        """Remove element from the end."""
        return self.items.pop(len(self.items)-1)

    def size(self):
        """Returns the size of queue."""
        return len(self.items)

    

#task8
def lists_testing():
    """Checks which list method is faster."""
    
    att = 100

    start = time.time()
    unordered_list = UnorderedList()
    for i in range(0, att):
        unordered_list.add(i)
    for i in range(0, att):
        unordered_list.pop()
    print("Time for unordered list:")
    print(time.time()- start)

    start = time.time()
    python_list = []
    for i in range(0, att):
        python_list.insert(0,i)
    for i in range(0, att):
        unordered_list.pop()
    print("Time for python list:")
    print(time.time()- start)


def main():
    
    print(parChecker(rm_self_tags("htmltext.txt")))
    l1 = UnorderedList()
    print(l1)
    l1.add(5)
    l1.add(8)
    l1.add(7)
    print(l1.search(5))
    print(l1.index(5))
    print(l1.pop(2))
    print(l1.size())
    print(l1.pop())
    print(l1.size())
    print(l1.search(5))
    print(l1.append(10))
    print(l1)

    lists_testing()
    queue_testing()

    l2 = StackUnordered()
    l2.push(5)
    l2.push(10)
    print(l2.size())
    l2.pop()
    print(l2.size())

    
if __name__ =="__main__":
    main()    

