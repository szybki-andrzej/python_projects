import sys
from lista4 import QueueBeg as Queue


class Vertex:
    def __init__(self,num):
        self.id = num
        self.connectedTo = {}
        self.color = 'white'       
        self.dist = sys.maxsize    
        self.pred = None           
        self.disc = 0              
        self.fin = 0
    def addNeighbor(self,nbr,weight=0):
        self.connectedTo[nbr] = weight
        
    def setColor(self,color):
        self.color = color
        
    def setDistance(self,d):
        self.dist = d

    def setPred(self,p):
        self.pred = p

    def setDiscovery(self,dtime):
        self.disc = dtime
        
    def setFinish(self,ftime):
        self.fin = ftime
        
    def getFinish(self):
        return self.fin
        
    def getDiscovery(self):
        return self.disc
        
    def getPred(self):
        return self.pred
        
    def getDistance(self):
        return self.dist
        
    def getColor(self):
        return self.color
    
    def getConnections(self):
        return self.connectedTo.keys()
        
    def getWeight(self,nbr):
        return self.connectedTo[nbr]
                
    def __str__(self):
        return str(self.id) + ":color " + self.color + ":disc " + str(self.disc) + ":fin " + str(self.fin) + ":dist " + str(self.dist) + ":pred \n\t[" + str(self.pred)+ "]\n"
    
    def getId(self):
        return self.id

    

class Graph:
    def __init__(self):
        self.vertList = {}
        self.numVertices = 0
        self.time = 0

    def addVertex(self,key):
        self.numVertices = self.numVertices + 1
        newVertex = Vertex(key)
        self.vertList[key] = newVertex
        return newVertex

    def getVertex(self,n):
        if n in self.vertList:
            return self.vertList[n]
        else:
            return None

    def __contains__(self,n):
        return n in self.vertList

    def addEdge(self,f,t,cost=0):
        if f not in self.vertList:
            nv = self.addVertex(f)
        if t not in self.vertList:
            nv = self.addVertex(t)
        self.vertList[f].addNeighbor(self.vertList[t], cost)

    def getVertices(self):
        return self.vertList.keys()

    def __iter__(self):
        return iter(self.vertList.values())

    def getEdges(self):
        edges = []
        for n in self:
            for w in n.getConnections():
                edges.append([n.getId(), w.getId()])
        return edges

    def dotRepr(self):
        dot = open("graphdot.txt","w")
        dot.write("digraph G {")
        dot.writelines("\n\t%s -> %s" %(a,b) for [a,b] in self.getEdges())
        dot.write("\n}")

    def bfs(self,start):
        verts = []
        start.setDistance(0)                            
        start.setPred(None)                             
        vertQueue = Queue()
        vertQueue.enqueue(start)
        verts.append(start)
        for aVertex in self:
            aVertex.setColor('white')
        while (vertQueue.size() > 0):
            currentVert = vertQueue.dequeue()
            for nbr in currentVert.getConnections():
                if (nbr.getColor() == 'white'):
                    nbr.setColor('gray')
                    verts.append(nbr)
                    nbr.setDistance(currentVert.getDistance() + 1)   
                    nbr.setPred(currentVert)                         
                    vertQueue.enqueue(nbr)
            currentVert.setColor('black')
        vertsorder = []
        for n in range(len(verts)):
            for i in verts:
                if i.dist == n:
                    vertsorder.append(i.id)
        return vertsorder

    def dfs(self):
        self.verts = []
        for aVertex in self:
            aVertex.setColor('white')
            aVertex.setPred(-1)
        for aVertex in self:
            if aVertex.getColor() == 'white':
                self.vertsDist = {}
                aVertex.dist = 0
                self._dfs(aVertex)

        return self.verts, self.vertsDist
        

    def _dfs(self,startVertex):
        startVertex.setColor('gray')
        self.verts.append(startVertex.id)
        self.time += 1
        self.vertsDist[str(startVertex.id)] = startVertex.dist
        startVertex.setDiscovery(self.time)
        for nextVertex in startVertex.getConnections():
            if nextVertex.getColor() == 'white':
                nextVertex.dist = startVertex.dist + 1
                
                nextVertex.setPred(startVertex)
                self._dfs(nextVertex)
        startVertex.setColor('black')
        self.time += 1
        startVertex.setFinish(self.time)

    
        
def main():
    g = Graph()
    u = g.addVertex(0)
    for i in range(1,6):
        g.addVertex(i)

    g.addEdge(0,1,5)
    g.addEdge(0,5,2)
    g.addEdge(1,2,4)
    g.addEdge(2,3,9)
    g.addEdge(3,4,7)
    g.addEdge(3,5,3)
    g.addEdge(4,0,1)
    g.addEdge(5,4,8)
    g.addEdge(5,2,1)
    print(g.getEdges())
    g.dotRepr()
    print(g.bfs(u))
    print(g.dfs())

    h = Graph()

    m = h.addVertex(7)
    for i in range(7):
        h.addVertex(i)

    h.addEdge(7,5,1)
    h.addEdge(5,2,1)
    h.addEdge(2,1,1)
    h.addEdge(5,4,1)
    h.addEdge(7,6,1)
    h.addEdge(6,4,1)
    h.addEdge(6,3,1)
    h.addEdge(3,1,1)
    h.addEdge(1,0,1)

    print(h.dfs())
    print(h.bfs(m))
    
    
            

if __name__=="__main__":
    main()

