import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import hmean
from scipy.stats.mstats import gmean
import math
def read_data():
    """Read and return data

    Returns:
        [array]: unsorted data array
    """
    A  = pd.read_csv("BTC-USD.csv")
    X = np.array(A["Open"])
    X = X[~np.isnan(X)]
    return X

#WYKRES DLA DANYCH
def draw_data_plot(data):
    plt.plot(data, color="magenta")
    plt.title("Wykres dla danych")
    plt.savefig("data_plot.png")
############ WZORY DO PODPUNKU 2 ###########

def arithmetic_average(X):
    suma = sum(X)
    return suma/len(X)

def truncated_average(k, X):
    n = len(X)
    suma = sum(X[k+1:n-k])
    return (1/(n - 2*k))*suma

def winsor_average(k, X):
    n = len(X)
    return (1/n)*((k + 1)*(X[k]) + sum(X[k+1:n-k-2]) + (k + 1)*(X[n-k-1]))

def truncated_average_plot(max_k, data):
    Y = []
    k_range = range(1, max_k+1)
    for k in k_range:
        Y.append(truncated_average(k, data))
    plt.plot(k_range, Y, color="cornflowerblue")
    plt.title("średnia ucinana zależna od k")
    plt.xlabel("k")
    plt.ylabel("wartość średniej")
    plt.savefig("truncated_average.png")
def winsor_average_plot(max_k, data):
    Y = []
    k_range = range(1, max_k+1)
    for k in k_range:
        Y.append(winsor_average(k, data))
    plt.plot(k_range, Y, color="midnightblue")
    plt.title("średnia winsorowska zależna od k")
    plt.xlabel("k")
    plt.ylabel("wartość średniej")
    plt.savefig("winsor_average.png")

def median(data):
    n = len(data)
    if n%2 == 0:
        return 0.5*(data[int(n/2)-1] + data[int(n/2)])
    else:
        return data[int((n + 1)/2) -1]
def qq_print(data):
    data = list(data)
    a = data.index(median(data))
    X1 = data[0:a] #0:180
    Q1 = median(X1)
    print("Q1 = ", Q1, " indeks: ", data.index(Q1))
    X2 = data[a+1:len(data)] #182:363
    Q3 = median(X2)
    print("Q3 = ", Q3, " indeks: ", data.index(Q3))
    print("IQR = ", Q3-Q1)

def var(data):
    n = len(data)
    suma = sum([(x_i - arithmetic_average(data))**2 for x_i in data])
    return 1/(n-1)*suma

def average_deviation(data):
    n = len(data)
    suma = sum([abs(x_i - arithmetic_average(data)) for x_i in data])
    return suma/n

def asymmetry(data):
    n = len(data)
    suma = sum([((x_i - arithmetic_average(data))/np.sqrt(var(data)))**3 for x_i in data])
    return n/((n-1)*(n-2))*suma
def kurt(data):
    n = len(data)
    suma1 = sum([(x_i - arithmetic_average(data))**4 for x_i in data])
    suma2 = sum([(x_i - arithmetic_average(data))**2 for x_i in data])
    return (1/n*suma1)/(1/n*suma2)**2

def demp(X, x):
    n = len(X)
    sumX = 0
    for i in range(n):
        if X[i] < x:
            sumX += 1
    return 1/n * sumX




data = read_data()
# plt.boxplot(data)
# plt.title('boxplot')
# plt.savefig('boxplot.png')
# plt.show()
data.sort()
print(data[0])
print(data[-1])
print(len(data))
# print(data)
#
# plt.plot(data, [demp(data,x) for x in data])
# plt.grid()
# plt.title('dystrubuanta empiryczna')
# plt.savefig('emp_dist.png')
#
# plt.show()


# plt.hist(data,bins = 15,rwidth=0.85)
# plt.grid(axis = "y")
# plt.xlabel('Kwota')
# plt.ylabel('Częstość')
# plt.title('Histogram dla danych')
# plt.savefig("hist_plot3.png")
# plt.show()


# truncated_average_plot(50, data)
# winsor_average_plot(50, data)
# print("średnia arytmetyczna: ", arithmetic_average(data))
# print("średnia harmoniczna: ", hmean(data))
# print("średnia geometryczna: ", gmean(data))
# print("mediana: ", median(data))
# qq_print(data)
# print("rozstęp: ", data[len(data)-1]-data[0])
# print("wariancja: ", var(data))
# print("odchylenie standardowe: ", np.sqrt(var(data)))
# print("odchylenie przeciętne od wartości średniej: ", average_deviation(data))
# print("współczynnik zmienności: ", np.sqrt(var(data))/arithmetic_average(data))
# print("współczynnik skośności: ", asymmetry(data))
# print("kurtoza: ", kurt(data))
