from tkinter import *
import pygame
import random
import json


class Gui:
    """Klasa tworząca okno startowe gry."""
    def __init__(self,master):
        """Funkcja inicjalizująca okno startowe gry."""
        self.button = Button(root, text = "New game", command = game)
        self.button.pack()

        self.button2 = Button(root, text = "How to play", command = self.howtoplay)
        self.button2.pack()

        self.button3 = Button(root, text = "Best score", command = self.bestscore)
        self.button3.pack()

        self.button4 = Button(root, text = "Author", command = self.author)
        self.button4.pack()

        self.button5 = Button(root, text = "Quit", command = self.quiter)
        self.button5.pack()

        self.text = Text(root, height = 10, width =70)
        self.text.pack()

    def howtoplay(self):
        """Funkcja działająca pod przyciskiem 'how to play'."""
        self.text.delete(1.0,END)
        self.text.insert(INSERT, "You have to survive during the coronavirus epidemy. Use your soap shots (SPACE) to kill viruses, avoid policemans jumping above (UP BUTTON), and meet your friends, when policemans don't see the meeting. Have fun!")
        
    def author(self):
        """Funkcja działająca pod przyciskiem 'author'."""
        self.text.delete(1.0,END)
        self.text.insert(INSERT, "Author: Andrzej Woźniak known as szybki.andrzej")

    def  bestscore(self):
        """Funckja działająca pod przyciskiem 'bestscore'."""
        self.text.delete(1.0, END)
        self.text.insert(INSERT, "record to beat: " + str(json.load(open("bestscore.json", "rb"))))

    def quiter(self):
        """Funkcja działająca pod przyciskiem 'Quit'."""
        exit(0)

def game():
    """Funckja działająca pod przyciskiem 'new game', czyli rozpoczynająca grę."""
    pygame.init()
    pygame.display.set_caption("Coronavirus party")
    clock = pygame.time.Clock()
    soapSound = pygame.mixer.Sound('soaphit.wav') #dźwięk zderzenia pocisku-mydła z koronawirusem
    music = pygame.mixer.music.load('music.mp3')#muzyka grająca cały czas
    pygame.mixer.music.play(-1)#gdy skończy się piosenka w tle, zaczyna się od początku
    win = pygame.display.set_mode((500, 300))    

    class Player(object):
        """Obiekt gracz, czyli postać którą gramy."""
        walkRight = [pygame.image.load('R1.png'), pygame.image.load('R2.png'), pygame.image.load('R3.png'), pygame.image.load('R4.png'), pygame.image.load('R5.png'), pygame.image.load('R6.png'), pygame.image.load('R7.png'), pygame.image.load('R8.png'), pygame.image.load('R9.png')]
        def __init__(self,x,y,width,height):
        """Funckja inicjalizuja"""
            self.x = x
            self.y = y
            self.right = True
            self.walkCount = 0
            self.isjump = False
            self.jumpCount = 10
            self.width = width
            self.height = height
            self.hitbox = (self.x + 20, self.y+15, 28, 45)#dopasowuje hitbox do rzeczywistego widocznego obwodu postaci
        def draw(self,win):
        """Funckja rysująca."""
            if self.walkCount + 1 >= 27:#przy tworzeniu animacji wraca do pierwszego zdjęcia, przy wyświetlenia wszystkich
                self.walkCount = 0
                win.fill((255,255,255))
            if self.right:#wyświetla po kolei obrazki tworząc animację
                win.blit(self.walkRight[self.walkCount//3], (self.x,self.y))
                self.walkCount += 1
                self.hitbox = (self.x + 20, self.y+15, 28, 45)
                        
    class Projectile(object):
        """Obiekt pocisk, czyli mydło którym strzela gracz."""
        soap = pygame.image.load('soap.png')
        def __init__(self,x,y,facing):
        """Funkcja inicjalizująca."""
            self.x = x
            self.y = y
            self.facing = facing
            self.vel = 8*facing
        def draw(self,win):
        """Funkcja rysująca."""
            win.blit(self.soap,(self.x,self.y))
            
    class Policeman(object):
        """Obiekt policjant."""
        stand = pygame.image.load('policeman.png')
        def __init__(self,x,y):
        """Funkcja inicjalizująca."""
            self.x = x
            self.y = y
            self.vel = 7
            self.hitbox = (self.x + 20, self.y, 28, 60)

        def draw(self,win):
        """Funckja rysująca."""
            self.x-=self.vel#porusza sie lewo cały czas
            win.blit(self.stand,(self.x, self.y))
            self.hitbox = (self.x + 20, self.y, 28, 60)
            
    class Covid(object):
        """Obiekt koronawirus."""
        covidimage = pygame.image.load('covid.jpg')
        def __init__(self,x,y):
        """Funckja inicjalizująca."""
            self.x = x
            self.y = y
            self.vel = 7
            self.hitbox = (self.x+10, self.y+10, 44, 64)
        def draw(self, win):
        """Funkcja rysująca."""
            self.x-=self.vel
            win.blit(self.covidimage,(self.x,self.y))
            self.hitbox = (self.x+10, self.y+10, 44, 64)
    
    class Friend(object):
        """Obiekt przyjaciel."""
        friendimage = pygame.image.load('friend.jpg')
        def __init__(self,x,y):
        """Funkcja inicjalizująca."""
            self.x = x
            self.y = y
            self.vel = 7
            self.hitbox = (self.x +10, self.y + 8, 30, 50)
        def draw(self,win):
        """Funckja rysująca."""
            self.x-=self.vel
            win.blit(self.friendimage,(self.x,self.y))
            self.hitbox = (self.x +10, self.y + 8, 30, 50)

    font = pygame.font.SysFont('comicsans', 30, True)#generuje czcionki których użyje potem w funkcjach
    font2 = pygame.font.SysFont('comicsans', 70, True)
            
    def gameover():
        """Funkcja uruchamiana w przypadku przegranej."""
        text3 = font2.render('GAME OVER', 1, (0,0,0))#wyświetlanie tekstu na środku ekranu
        text4 = font2.render('total score: ' + str(score), 1, (0,0,0))
        win.blit(text3, (250 - (text3.get_width()/2),50))
        win.blit(text4, (250 - (text4.get_width()/2),150))
        pygame.display.update()
        try:#zapisanie rekordu do pliku gdy jest większy niż poprzedni
            with open("bestscore.json", "rb") as js:
                if (json.load(js)) < score:
                    with open("bestscore.json", "w") as ms:
                        json.dump(score,ms)

        except:#zapisywanie rekordu gdy nie ma pliku
            with open("bestscore.json", "w") as ms:
                json.dump(score,ms)
                
        i = 0#zatrzymywanie akcji w oknie
        while i < 300:
            pygame.time.delay(10)
            i += i
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    i = 301
                    pygame.quit()                

    def redrawGameWindow():
        """Funkcja rysująca okno gry w określonych odstępach czasowych."""

        win.fill((255,255,255))

        text = font.render('Score: ' + str(score), 1, (0,0,0))
        text2 = font.render('Time: ' + str(time), 1, (0,0,0))

        man.draw(win)
        win.blit(text, (380,10))
        win.blit(text2, (10,10))
        
        for policeman in policemans:
            policeman.draw(win)

        for covid in covids:
            covid.draw(win)

        for friend in friends:
            friend.draw(win)

        for bullet in bullets:
            bullet.draw(win)
        man.draw(win)
        
        pygame.display.update()

    man = Player(150,200,64,64)
    bullets = []#wrzucam wszystkie obiekty poza graczem do tablic by mieć do nich łatwy dostęp
    policemans = []
    covids = []
    friends = []
    shootLoop = 0
    run = True
    randLoop = 0
    timeLoop = 0
    score = 0
    time = 0
        
    while run:#jeśli jakaś akcja w środku zmieni run na false gra zatrzymuje sie i wraca do okna startowego
        clock.tick(27)

        randLoop += 1
        timeLoop += 1

        if timeLoop >27:
            timeLoop = 0
            time += 1
            score += 1#punkt za każdą przetrwaną sekundę
            
        if randLoop >25:
            randLoop = 0 

        if shootLoop > 0:#maksymalnie 5 pocisków na raz
            shootLoop += 1
        if shootLoop >5: 
            shootLoop = 0

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

        for bullet in bullets:#gdy pocisk zderzy się z policjantem odpala funkcję gameover(), podobnie poniżej
            for policeman in policemans:
                if bullet.x + 30 > policeman.hitbox[0] and bullet.x < policeman.hitbox[0]+policeman.hitbox[2]:
                    gameover()
                    bullets.pop(bullets.index(bullet))

        for bullet in bullets:
            for covid in covids:
                if bullet.x + 30 > covid.hitbox[0] and bullet.x < covid.hitbox[0]+covid.hitbox[2]:
                    score +=5
                    soapSound.play()
                    covids.pop(covids.index(covid))
                    bullets.pop(bullets.index(bullet))

        for bullet in bullets:
            for friend in friends:
                if bullet.x + 30 > friend.hitbox[0] and bullet.x < friend.hitbox[0]+friend.hitbox[2]:
                    gameover()
                    bullets.pop(bullets.index(bullet))


        for policeman in policemans:
            if man.hitbox[0] + man.hitbox[2] > policeman.hitbox[0] and man.hitbox[0]<policeman.hitbox[0] + policeman.hitbox[2]:
                if man.hitbox[1] + man.hitbox[3] > policeman.hitbox[1]:
                    gameover()


        for covid in covids:
            if man.hitbox[0] + man.hitbox[2] > covid.hitbox[0] and man.hitbox[0]<covid.hitbox[0] + covid.hitbox[2]:
                if man.hitbox[1] + man.hitbox[3] > covid.hitbox[1]:
                    gameover()

        for friend in friends:
            if man.hitbox[0] + man.hitbox[2] > friend.hitbox[0] and man.hitbox[0]<friend.hitbox[0] + friend.hitbox[2]:
                if man.hitbox[1] + man.hitbox[3] > friend.hitbox[1]:
                    if len(policemans) == 0:
                        score += 15
                        friends.pop(friends.index(friend))
                    else:
                        gameover()

        for bullet in bullets:#zniaknie pocisku gdy wyjdzie za planszę, podobnie z resztą
            if bullet.x < 500 and bullet.x > 0:
                bullet.x +=bullet.vel
            else:
                bullets.pop(bullets.index(bullet))

        for policeman in policemans:
            if policeman.x > 500 or policeman.x < -30:
                policemans.pop(policemans.index(policeman))

        for covid in covids:
            if covid.x > 500 or covid.x < -30:
                covids.pop(covids.index(covid))

        for friend in friends:
            if friend.x > 500 or friend.x < -30:
                friends.pop(friends.index(friend))
                

        if randLoop == 0:#randomowe generowanie policjantów, wirusów i przyjaciół
            a = random.randint(1,10)
            if a == 1 or a == 2:
                policemans.append(Policeman(500,200))
            if a == 3 or a == 4 or a == 5:
                covids.append(Covid(500,200))
            if a == 6 or a == 7 or a == 8:
                friends.append(Friend(500,200))
            
        keys = pygame.key.get_pressed()

        if not (man.isjump):#skakanie gdy nie jest wykonywany skok
            if keys[pygame.K_UP]:
                man.isjump = True
            if keys[pygame.K_SPACE] and shootLoop ==0:
                if len(bullets) < 5:#strzelanie gdy jest mniej niż 5 pocisków
                    bullets.append(Projectile(round(man.x + man.width//2),round(man.y + man.height//2), 1))
                shootLoop = 1

        else:#wykonywanie skakania czyli parabola
            if man.jumpCount >= -10:
                neq = 1
                if man.jumpCount < 0:
                    neq = -1
                    
                man.y -= (man.jumpCount**2) * 0.5 * neq
                man.jumpCount -=1
            else:
                man.isjump = False
                man.jumpCount = 10

        redrawGameWindow()
    
    pygame.quit()

if __name__ == "__main__":
    root = Tk()
    root.title("Coronavirus party")
    root.geometry("500x250")
    Gui(root)
    root.mainloop()
