import csv
import matplotlib.pyplot as plt
import numpy as np
from statistics import median
from scipy.stats import skew, kurtosis, norm, kstest, jarque_bera
import scipy


btc_data = []
doge_data = []
with open('BTC-USD.csv', 'r') as csvfile:
    csvreader = csv.reader(csvfile, delimiter=',')

    for row in csvreader:
        btc_data.append(row[1])

with open('DOGE-USD.csv', 'r') as csvfile:
    csvreader = csv.reader(csvfile, delimiter=',')

    for row in csvreader:
        doge_data.append(row[1])

btc_data = np.array([float(btc_data[i]) for i in range(1, 367)])
doge_data = np.array([float(doge_data[i]) for i in range(1, 367)])

n = len(btc_data)
print("number of observations:", n)

xs = np.linspace(1, n, n, dtype=int)


plt.plot(xs, btc_data)
plt.savefig("btc_data.jpg")
plt.show()
plt.plot(xs, doge_data)
plt.savefig("doge_data.jpg")
plt.show()

# means

mean_btc = np.mean(btc_data)
mean_doge = np.mean(doge_data)

print("means:", mean_btc, mean_doge)

# variance

var_btc = np.var(btc_data)
var_doge = np.var(doge_data)

print("variances:", var_btc, var_doge)

# median

med_btc = median(btc_data)
med_doge = median(doge_data)

print("medians:", med_btc, med_doge)

# standard deviation

stdev_btc = np.sqrt(var_btc)
stdev_doge = np.sqrt(var_doge)

print("standard deviations: ", stdev_btc, stdev_doge)

# skewness

skew_btc = skew(btc_data)
skew_doge = skew(doge_data)

print("skewnesses: ", skew_btc, skew_doge)

# kurtosis

kurt_btc = kurtosis(btc_data)
kurt_doge = kurtosis(doge_data)

print("kurtosises: ",kurt_btc, kurt_doge)

# linear regression

#x_mean = np.mean(xs)


def regr(xss, yss):
    x_mean = np.mean(xss)
    y_mean = np.mean(yss)
    n = len(xss)
    b1 = sum([(xss[i] - x_mean) * (yss[i] - y_mean) for i in range(n)]) / sum([(xss[i] - x_mean) ** 2 for i in range(n)])
    b0 = y_mean - x_mean * b1
    return b0, b1


b0, b1 = regr(btc_data, doge_data)

print("b0 and b1: ", b0, b1)

est = btc_data * b1 + b0


plt.scatter(btc_data, doge_data, s=3)
plt.plot(btc_data, est)
plt.savefig("data_regression.jpg")
plt.show()


# coefficient of determination


def r(data, est):
    y_mean = np.mean(data)
    n = len(data)
    return 1 - sum([(data[i] - est[i]) ** 2 for i in range(n)]) / sum([(data[i] - y_mean) ** 2 for i in range(n)])


print("coefficient of determination: ", r(doge_data, est))

# confidence interval


def trust(est, par, n):
    z = norm.ppf(par)
    return est - z*((1/n)**(1/2)), est + z*((1/n)**(1/2))


print("confidence interval for b0: ", trust(b0, 0.95, n))
print("confidence interval for b1: ", trust(b1, 0.95, n))


# residues

ei = doge_data - est

plt.scatter(btc_data, ei, s=3)
plt.savefig("residues.jpg")
plt.show()

ei_mean = np.mean(ei)


kstest = kstest((ei - ei_mean) / np.std(ei), "norm")

print(kstest)

jbtest = jarque_bera(ei)

print(jbtest)

xss = np.linspace(-1, 1, 100)


ei_d = (1/(np.std(ei) * np.sqrt(2*np.pi))) * np.exp(-(xss - ei_mean)**2 / (2*np.var(ei)))


plt.plot(xss, ei_d)
plt.hist(ei, density=True)
plt.savefig("residues_norm.jpg")
plt.show()

# deleting observations

Q1 = np.quantile(ei, 0.25)
Q3 = np.quantile(ei, 0.75)
QR = Q3 - Q1


TF = np.random.choice([False], len(ei))
for i in range(n):
    if Q1 - QR <= ei[i] <= Q3 + QR:
        TF[i] = True
    else:
        TF[i] = False

ei_new = ei[TF]

print(len(ei) - len(ei_new), " observations deleted")

btc_new = btc_data[TF]
doge_new = doge_data[TF]


btc_mean_new = np.mean(btc_new)
doge_mean_new = np.mean(doge_new)

n_new = len(btc_new)


b0_new, b1_new = regr(btc_new, doge_new)

print("b0_new and b1_new: ", b0_new, b1_new)

est_new = btc_new * b1_new + b0_new


plt.scatter(btc_new, doge_new, s=3)
plt.plot(btc_new, est_new)
plt.savefig("new_data_regression.jpg")
plt.show()

print("new coefficient of determination: ", r(doge_new, est_new))

print("confidence interval for b0_new: ", trust(b0_new, 0.95, n_new))
print("confidence interval for b1_new: ", trust(b1_new, 0.95, n_new))


ei_new = doge_new - est_new

plt.scatter(btc_new, ei_new, s=3)
plt.savefig("residues_new.jpg")
plt.show()

ei_new_mean = np.mean(ei_new)

ks_new = scipy.stats.kstest((ei_new - ei_new_mean) / np.std(ei_new), "norm")

print(ks_new)

jb_new = jarque_bera(ei_new)

print(jb_new)

ei_d_new = (1/(np.std(ei_new) * np.sqrt(2*np.pi))) * np.exp(-(xss - ei_new_mean)**2 / (2*np.var(ei_new)))


plt.plot(xss, ei_d_new)
plt.hist(ei_new, density=True)
plt.savefig("residues_norm_new.jpg")
plt.show()
